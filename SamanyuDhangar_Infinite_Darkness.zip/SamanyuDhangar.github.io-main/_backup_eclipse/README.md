# PROJECT : ECLIPSE — Competition Edition

A responsive, framework-free cybersecurity portfolio for Samanyu Dhangar.

## Included
- Cinematic boot sequence with a custom animated dragon sigil and rotating arcane-style geometry.
- Dark atmospheric background, depth grid, corner runes, scroll progress and reveal effects.
- Landing / Explore / Connect views with a persistent back-to-gate control.
- Profile, mission tabs, skills, journey, projects and credentials.
- Local-only password strength estimate and an HTTP request/header learning inspector.
- Reduced-motion support and responsive layout.

## Run locally
Open `index.html`, or run `python3 -m http.server 8000` from this folder and visit `http://localhost:8000`.

## Publish on GitHub Pages
Upload the contents of this folder to the repository root. No build step is required.

## Notes
The HTTP inspector only analyzes text pasted into the browser. It does not capture live network traffic or send the input anywhere. Password strength and crack-time estimates are educational approximations, not guarantees. External Google Fonts are used when network access is available; system fonts remain as fallback.
