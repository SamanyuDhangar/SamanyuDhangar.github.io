/* config.js — the only file you need to edit for contact details.
   Leave a value as "" and that link is simply hidden (nothing is invented). */
window.SD = window.SD || {};
SD.config = {
  email: "",                                   // e.g. "you@example.com"
  github: "https://github.com/SamanyuDhangar",
  linkedin: "https://www.linkedin.com/in/samanyu-dhangar-191529413/",
  tryhackme: "",                               // e.g. "https://tryhackme.com/p/YourUsername"
  eyesOfTruth: "https://eyesoftruth.onrender.com/"
};
