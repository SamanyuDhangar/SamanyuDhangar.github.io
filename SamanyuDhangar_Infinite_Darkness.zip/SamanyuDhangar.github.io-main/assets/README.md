Project assets
